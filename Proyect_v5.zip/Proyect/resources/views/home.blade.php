@extends('layouts.appNavegando')

@section('content')
<h2>esta es la home Page</h2>
@endsection