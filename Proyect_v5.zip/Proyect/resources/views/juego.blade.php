@extends('layouts.appNavegando')

@section('content')
<h2>esta es la Page juego</h2>
@endsection