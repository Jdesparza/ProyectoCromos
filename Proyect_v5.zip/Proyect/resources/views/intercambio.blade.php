@extends('layouts.appNavegando')

@section('content')
<h2>esta es la Page intercambio</h2>
@endsection