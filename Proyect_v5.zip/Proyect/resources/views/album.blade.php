@extends('layouts.appNavegando')

@section('content')
<h2>esta es la Page album</h2>
@endsection