<?php $__env->startSection('content'); ?>
    <div class="imgCuerpo">
        <section class="sectionCuerpo">
            <img src="../../img/undraw_Books_l33t 1 1.png" alt="" class="imgPrimero">
            <div class="imgRodeaCuerpo1">
                <img src="../../img/crecimiento 1.png" alt="" class="img1">
            </div>
            <div class="imgRodeaCuerpo2">
                <img src="../../img/dinamica 1.png" alt="" class="img2">
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appInicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aplicaciones\proyectoIntegrador\laravel\Proyect\resources\views/welcome.blade.php ENDPATH**/ ?>